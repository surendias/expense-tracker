import EntryForm from '../EntryForm';
import EntryList from '../EntryList';

export default function EntryTab({ entries, categories, onRefresh }) {
  return (
    <>
      
      
      <EntryList
        entries={entries}
        categories={categories}
        onRefresh={onRefresh}
        className="mb-4"
      />
        <h5 className="mb-3 mt-3">Add New Entry</h5>
      <EntryForm categories={categories} onCreated={onRefresh} />
    </>
  );
}
